# FoodFlow: Online Food Ordering & Delivery

A finished college-project web application built with Flask, HTML, CSS and JavaScript. It is designed specifically for the existing MySQL schema described in the supplied DBMS documentation:

- `CUSTOMER`, `RESTAURANT`, `MENU_ITEM`, `ORDERS`, `ORDER_ITEM`, `PAYMENT`, and `DELIVERY`
- Views: `vw_delivery_status_report`, `vw_restaurant_sales_summary`
- Existing triggers and generated fields remain database-owned.

The project **does not create, drop, alter, seed, or otherwise recreate your database**. It only reads and writes normal application records through the existing schema.

## Included features

- Professional responsive dashboard with customer, order, revenue and active-delivery statistics.
- Restaurant and availability-aware menu browsing with a single-restaurant cart.
- Transactional multi-item order placement: order, order items, payment and delivery records are committed together or rolled back.
- Customer-filtered order history and detailed item/payment/delivery tracking.
- Admin reporting sourced directly from both documented MySQL views.
- Delivery-status management; the documented database trigger sets an order to `DELIVERED`.
- Menu availability endpoint for admin integration (`PATCH /api/menu/<id>`).
- Parameterized SQL queries, input validation, error responses, and no credentials in source control.

## Setup and run

1. Make sure MySQL is running and your documented schema already exists. The documentation uses the schema name `food_ordering_db`; use its actual name if different.
2. In this project folder, copy `.env.example` to a new file named `.env`.
3. Set the values in `.env` for your MySQL host, port, database name, username, and password. Use an account with at least `SELECT`, `INSERT`, and `UPDATE` permissions. The report pages require `SELECT` on the two views.
4. Create and activate a virtual environment (recommended):

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

5. Install the dependencies and start the application:

   ```powershell
   pip install -r requirements.txt
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in a browser.

## Configuration

All connection settings belong in `.env`, which is intentionally ignored by Git:

| Setting | Meaning |
|---|---|
| `MYSQL_HOST` / `MYSQL_PORT` | MySQL server location |
| `MYSQL_DATABASE` | Existing database/schema name |
| `MYSQL_USER` / `MYSQL_PASSWORD` | Existing MySQL user credentials |
| `FLASK_SECRET_KEY` | Long random secret for a non-development deployment |
| `FLASK_DEBUG` | Use `true` only during local development |
| `APP_ADMIN_USERNAME` / `APP_ADMIN_PASSWORD` | Login credentials for the FoodFlow admin portal |

## Login

The supplied database schema has no application-user table, so the web application uses a Flask session login configured in `.env`. Set a private administrator username and strong password before running the app. Login protects the dashboard and application APIs; admin management and reporting routes additionally require the administrator session. This layer does not change the existing MySQL schema or replace the database-level DCL permissions.

## Important assumptions

1. The table/column names and enums exactly match the submitted documentation, including uppercase table names.
2. Your MySQL account can use the two documented views. If the views are absent, run the view SQL from the DBMS documentation once as a database administrator; this app will not create them automatically.
3. The documented `sp_place_order` supports one item only. The cart uses its own safe database transaction by default for every cart while continuing to rely on the documented triggers for order totals and delivery completion. Set `USE_STORED_PROCEDURE=true` only if you have confirmed that your local procedure exactly matches the documented version.
4. This classroom project deliberately has no login system or real payment gateway. Payment is recorded as `PENDING`, matching the documented enum and workflow.

## Quick verification

After configuring `.env`, visit `http://127.0.0.1:5000/api/health`. A successful response confirms the app can reach the configured existing database. If it reports a connection/schema failure, review the `.env` database name, credentials, and MySQL service.
