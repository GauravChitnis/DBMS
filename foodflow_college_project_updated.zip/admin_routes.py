"""Administrative Flask blueprint for creating records and changing order status."""
from functools import wraps
from flask import Blueprint, jsonify, request
from mysql.connector import Error


def create_admin_blueprint(connection, api_error, order_statuses):
    admin = Blueprint("admin", __name__, url_prefix="/api/admin")

    def guarded(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except ValueError as exc:
                return api_error(str(exc), 400)
            except Error:
                return api_error("Database operation failed. Check the values and database connection.", 500)
        return wrapped

    def body():
        data = request.get_json(silent=True)
        if not isinstance(data, dict): raise ValueError("A JSON request body is required.")
        return data

    def text(data, key, minimum=1, maximum=255):
        value = str(data.get(key, "")).strip()
        if not minimum <= len(value) <= maximum: raise ValueError(f"{key.replace('_', ' ').title()} must contain {minimum}-{maximum} characters.")
        return value

    @admin.post("/customers")
    @guarded
    def add_customer():
        data = body(); name, email = text(data, "name", 2, 100), text(data, "email", 5, 100)
        phone, address = text(data, "phone", 7, 15), text(data, "address", 5, 255)
        if "@" not in email: raise ValueError("Enter a valid email address.")
        with connection() as conn:
            cur = conn.cursor(); cur.execute("INSERT INTO CUSTOMER (name,email,phone,address) VALUES (%s,%s,%s,%s)", (name, email, phone, address)); conn.commit(); record_id = cur.lastrowid
        return jsonify(message="Customer added successfully.", customer_id=record_id), 201

    @admin.post("/restaurants")
    @guarded
    def add_restaurant():
        data = body(); name, phone, address = text(data, "name", 2, 100), text(data, "phone", 7, 15), text(data, "address", 5, 255)
        try: rating = float(data.get("rating", 0))
        except (TypeError, ValueError): raise ValueError("Rating must be a number from 0 to 5.")
        if not 0 <= rating <= 5: raise ValueError("Rating must be a number from 0 to 5.")
        with connection() as conn:
            cur = conn.cursor(); cur.execute("INSERT INTO RESTAURANT (name,phone,address,rating) VALUES (%s,%s,%s,%s)", (name, phone, address, rating)); conn.commit(); record_id = cur.lastrowid
        return jsonify(message="Restaurant added successfully.", restaurant_id=record_id), 201

    @admin.post("/restaurants/<int:restaurant_id>/menu")
    @guarded
    def add_menu_item(restaurant_id):
        data = body(); name, category = text(data, "name", 2, 100), text(data, "category", 2, 50)
        try: price = float(data.get("price"))
        except (TypeError, ValueError): raise ValueError("Price must be a positive number.")
        if price <= 0: raise ValueError("Price must be a positive number.")
        with connection() as conn:
            cur = conn.cursor(); cur.execute("SELECT restaurant_id FROM RESTAURANT WHERE restaurant_id=%s", (restaurant_id,))
            if not cur.fetchone(): return api_error("Restaurant not found.", 404)
            cur.execute("INSERT INTO MENU_ITEM (restaurant_id,name,category,price,availability) VALUES (%s,%s,%s,%s,TRUE)", (restaurant_id, name, category, price)); conn.commit(); record_id = cur.lastrowid
        return jsonify(message="Menu item added successfully.", menu_item_id=record_id), 201

    @admin.patch("/orders/<int:order_id>/status")
    @guarded
    def change_order_status(order_id):
        status = str(body().get("status", "")).upper()
        if status not in order_statuses: raise ValueError("Choose a valid order status.")
        with connection() as conn:
            cur = conn.cursor(); cur.execute("UPDATE ORDERS SET status=%s WHERE order_id=%s", (status, order_id)); conn.commit()
            if cur.rowcount == 0: return api_error("Order not found.", 404)
        return jsonify(message="Order status updated.")

    return admin
