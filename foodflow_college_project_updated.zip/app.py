"""Flask application for the existing Online Food Ordering & Delivery schema."""
from __future__ import annotations

import os
from contextlib import contextmanager
from datetime import datetime
from decimal import Decimal
from functools import wraps

import mysql.connector
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from mysql.connector import Error
from admin_routes import create_admin_blueprint

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "development-only-change-me")

PAYMENT_METHODS = {"CARD", "UPI", "CASH_ON_DELIVERY", "WALLET"}
ORDER_STATUSES = {"PLACED", "CONFIRMED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED"}
DELIVERY_STATUSES = {"ASSIGNED", "PICKED_UP", "OUT_FOR_DELIVERY", "DELIVERED", "FAILED"}


def db_config():
    return {
        "host": os.getenv("MYSQL_HOST", "127.0.0.1"), "port": int(os.getenv("MYSQL_PORT", "3306")),
        "database": os.getenv("MYSQL_DATABASE", "food_ordering_db"), "user": os.getenv("MYSQL_USER", "root"),
        "password": os.getenv("MYSQL_PASSWORD", ""), "connection_timeout": int(os.getenv("MYSQL_CONNECT_TIMEOUT", "10")),
    }


@contextmanager
def connection():
    conn = mysql.connector.connect(**db_config())
    try:
        yield conn
    finally:
        conn.close()


def json_value(value):
    if isinstance(value, Decimal): return float(value)
    if isinstance(value, datetime): return value.isoformat(sep=" ", timespec="minutes")
    return value


def rows(cursor):
    return [{key: json_value(value) for key, value in row.items()} for row in cursor.fetchall()]


def api_error(message, code=400):
    return jsonify(error=message), code


def api_route(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except ValueError as exc:
            return api_error(str(exc), 400)
        except Error as exc:
            app.logger.exception("Database request failed")
            return api_error("Database operation failed. Check the connection and schema configuration.", 503 if exc.errno in (2003, 1045, 1049) else 500)
        except Exception:
            app.logger.exception("Unexpected request failure")
            return api_error("An unexpected error occurred.", 500)
    return wrapped


def payload():
    data = request.get_json(silent=True)
    if not isinstance(data, dict): raise ValueError("A JSON request body is required.")
    return data


def positive_int(value, field):
    try: value = int(value)
    except (TypeError, ValueError): raise ValueError(f"{field} must be a whole number.")
    if value < 1: raise ValueError(f"{field} must be greater than zero.")
    return value


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
@api_route
def health():
    with connection() as conn:
        cur = conn.cursor(); cur.execute("SELECT 1"); cur.fetchone()
    return jsonify(status="connected", database=db_config()["database"])


@app.get("/api/dashboard")
@api_route
def dashboard():
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT (SELECT COUNT(*) FROM CUSTOMER) customers, COUNT(*) total_orders, COALESCE(SUM(total_amount), 0) revenue, COALESCE(SUM(status = 'OUT_FOR_DELIVERY'), 0) active_deliveries FROM ORDERS")
        stats = rows(cur)[0]
        cur.execute("SELECT order_id, customer_name, restaurant_name, total_amount, order_status, delivery_status, order_date FROM vw_delivery_status_report ORDER BY order_date DESC LIMIT 6")
        recent = rows(cur)
    return jsonify(stats=stats, recent=recent)


@app.get("/api/restaurants")
@api_route
def restaurants():
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT r.*, COUNT(m.menu_item_id) AS item_count FROM RESTAURANT r LEFT JOIN MENU_ITEM m ON m.restaurant_id=r.restaurant_id AND m.availability=TRUE GROUP BY r.restaurant_id ORDER BY r.rating DESC, r.name")
        return jsonify(rows(cur))


@app.get("/api/restaurants/<int:restaurant_id>/menu")
@api_route
def menu(restaurant_id):
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT menu_item_id, restaurant_id, name, category, price, availability FROM MENU_ITEM WHERE restaurant_id=%s ORDER BY availability DESC, category, name", (restaurant_id,))
        return jsonify(rows(cur))


@app.get("/api/customers")
@api_route
def customers():
    with connection() as conn:
        cur = conn.cursor(dictionary=True); cur.execute("SELECT customer_id, name, email, phone, address FROM CUSTOMER ORDER BY name")
        return jsonify(rows(cur))


@app.get("/api/orders")
@api_route
def orders():
    customer_id = request.args.get("customer_id", type=int)
    sql = "SELECT o.order_id,c.name customer,r.name restaurant,o.order_date,o.total_amount,o.status,p.method,p.status payment_status,d.delivery_status FROM ORDERS o JOIN CUSTOMER c ON c.customer_id=o.customer_id JOIN RESTAURANT r ON r.restaurant_id=o.restaurant_id LEFT JOIN PAYMENT p ON p.order_id=o.order_id LEFT JOIN DELIVERY d ON d.order_id=o.order_id"
    args = ()
    if customer_id: sql += " WHERE o.customer_id=%s"; args = (customer_id,)
    sql += " ORDER BY o.order_date DESC"
    with connection() as conn:
        cur = conn.cursor(dictionary=True); cur.execute(sql, args); return jsonify(rows(cur))


@app.get("/api/orders/<int:order_id>")
@api_route
def order_detail(order_id):
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT o.*,c.name customer,c.email,c.phone,r.name restaurant,r.address restaurant_address,p.payment_id,p.amount payment_amount,p.method,p.status payment_status,p.payment_date,d.delivery_address,d.delivery_status,d.assigned_at,d.delivered_at FROM ORDERS o JOIN CUSTOMER c ON c.customer_id=o.customer_id JOIN RESTAURANT r ON r.restaurant_id=o.restaurant_id LEFT JOIN PAYMENT p ON p.order_id=o.order_id LEFT JOIN DELIVERY d ON d.order_id=o.order_id WHERE o.order_id=%s", (order_id,))
        record = cur.fetchone()
        if not record: return api_error("Order not found.", 404)
        cur.execute("SELECT oi.order_item_id,mi.name,mi.category,oi.quantity,oi.unit_price,oi.subtotal FROM ORDER_ITEM oi JOIN MENU_ITEM mi ON mi.menu_item_id=oi.menu_item_id WHERE oi.order_id=%s", (order_id,))
        return jsonify(order={key: json_value(value) for key, value in record.items()}, items=rows(cur))


@app.post("/api/orders")
@api_route
def create_order():
    data = payload(); customer_id = positive_int(data.get("customer_id"), "customer_id")
    items = data.get("items")
    if not isinstance(items, list) or not items: raise ValueError("Add at least one menu item to the cart.")
    method = str(data.get("payment_method", "")).upper()
    if method not in PAYMENT_METHODS: raise ValueError("Choose a valid payment method.")
    address = str(data.get("delivery_address", "")).strip()
    if not (5 <= len(address) <= 255): raise ValueError("Enter a delivery address between 5 and 255 characters.")
    normalized = [(positive_int(i.get("menu_item_id"), "menu_item_id"), positive_int(i.get("quantity"), "quantity")) for i in items if isinstance(i, dict)]
    if len(normalized) != len(items) or len({item[0] for item in normalized}) != len(normalized): raise ValueError("Cart items must be valid and unique.")
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        try:
            cur.execute("SELECT customer_id FROM CUSTOMER WHERE customer_id=%s", (customer_id,))
            if not cur.fetchone(): raise ValueError("Selected customer does not exist.")
            placeholders = ",".join(["%s"] * len(normalized)); ids = tuple(item[0] for item in normalized)
            cur.execute(f"SELECT menu_item_id,restaurant_id,price,availability FROM MENU_ITEM WHERE menu_item_id IN ({placeholders})", ids)
            catalog = {row["menu_item_id"]: row for row in cur.fetchall()}
            if len(catalog) != len(normalized): raise ValueError("One or more menu items no longer exist.")
            if any(not row["availability"] for row in catalog.values()): raise ValueError("An item in the cart is currently unavailable.")
            restaurant_ids = {catalog[item_id]["restaurant_id"] for item_id, _ in normalized}
            if len(restaurant_ids) != 1: raise ValueError("One order can contain items from only one restaurant.")
            restaurant_id = restaurant_ids.pop()
            # Use the documented stored procedure when its single-item contract fits.
            # Multi-item carts use the equivalent application transaction below.
            cur.execute("SELECT COUNT(*) AS present FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA=DATABASE() AND ROUTINE_NAME='sp_place_order' AND ROUTINE_TYPE='PROCEDURE'")
            procedure_present = bool(cur.fetchone()["present"])
            # The documented procedure is optional and handles only one item. It is
            # disabled by default because a local schema may contain a differently
            # defined version; the safe transaction below supports every cart.
            procedure_enabled = os.getenv("USE_STORED_PROCEDURE", "false").lower() == "true"
            if len(normalized) == 1 and procedure_present and procedure_enabled:
                item_id, quantity = normalized[0]
                result = cur.callproc("sp_place_order", (customer_id, restaurant_id, item_id, quantity, method, address, 0))
                for result_set in cur.stored_results():
                    result_set.fetchall()
                order_id = int(result[-1])
                conn.commit()
                return jsonify(message="Order placed successfully using the database procedure.", order_id=order_id), 201
            conn.start_transaction()
            # Re-lock the cart records only for the application-managed transaction.
            cur.execute(f"SELECT menu_item_id,restaurant_id,price,availability FROM MENU_ITEM WHERE menu_item_id IN ({placeholders}) FOR UPDATE", ids)
            catalog = {row["menu_item_id"]: row for row in cur.fetchall()}
            if any(not row["availability"] for row in catalog.values()): raise ValueError("An item in the cart is currently unavailable.")
            cur.execute("INSERT INTO ORDERS (customer_id, restaurant_id, status) VALUES (%s,%s,'PLACED')", (customer_id, restaurant_id)); order_id = cur.lastrowid
            for item_id, quantity in normalized:
                cur.execute("INSERT INTO ORDER_ITEM (order_id, menu_item_id, quantity, unit_price) VALUES (%s,%s,%s,%s)", (order_id, item_id, quantity, catalog[item_id]["price"]))
            cur.execute("SELECT total_amount FROM ORDERS WHERE order_id=%s", (order_id,)); total = cur.fetchone()["total_amount"]
            cur.execute("INSERT INTO PAYMENT (order_id, amount, method, status) VALUES (%s,%s,%s,'PENDING')", (order_id, total, method))
            cur.execute("INSERT INTO DELIVERY (order_id, delivery_address, delivery_status) VALUES (%s,%s,'ASSIGNED')", (order_id, address))
            conn.commit()
        except Exception:
            conn.rollback(); raise
    return jsonify(message="Order placed successfully.", order_id=order_id), 201


@app.get("/api/reports")
@api_route
def reports():
    with connection() as conn:
        cur = conn.cursor(dictionary=True); cur.execute("SELECT * FROM vw_restaurant_sales_summary ORDER BY total_revenue DESC, restaurant_name"); sales = rows(cur)
        cur.execute("SELECT * FROM vw_delivery_status_report ORDER BY order_date DESC"); delivery = rows(cur)
    return jsonify(sales=sales, delivery=delivery)


@app.patch("/api/menu/<int:item_id>")
@api_route
def update_menu(item_id):
    data = payload()
    if not isinstance(data.get("availability"), bool): raise ValueError("availability must be true or false.")
    with connection() as conn:
        cur = conn.cursor(); cur.execute("UPDATE MENU_ITEM SET availability=%s WHERE menu_item_id=%s", (data["availability"], item_id)); conn.commit()
        if cur.rowcount == 0: return api_error("Menu item not found.", 404)
    return jsonify(message="Menu availability updated.")


@app.patch("/api/orders/<int:order_id>/delivery")
@api_route
def update_delivery(order_id):
    data = payload(); status = str(data.get("delivery_status", "")).upper()
    if status not in DELIVERY_STATUSES: raise ValueError("Choose a valid delivery status.")
    with connection() as conn:
        cur = conn.cursor(); cur.execute("UPDATE DELIVERY SET delivery_status=%s, assigned_at=COALESCE(assigned_at, NOW()), delivered_at=CASE WHEN %s='DELIVERED' THEN NOW() ELSE delivered_at END WHERE order_id=%s", (status, status, order_id)); conn.commit()
        if cur.rowcount == 0: return api_error("Delivery record not found.", 404)
    return jsonify(message="Delivery status updated. The database trigger handles delivered orders.")


app.register_blueprint(create_admin_blueprint(connection, api_error, ORDER_STATUSES))


if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
